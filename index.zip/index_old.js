'use strict';
var Alexa = require('alexa-sdk');
const AWS = require('aws-sdk');
var search = require('youtube-search');
const uStream = require('youtube-audio-stream')
var Stream = require('stream');
var url = 'http://youtube.com/watch?v='
var fs = require('fs');
var writemp3 = fs.createWriteStream('/tmp/response.mp3');
var S3_BUCKET = process.env['S3_BUCKET'];
var API_KEY = process.env['API_KEY'];
var s3 = new AWS.S3();

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT']

var opts = {
  maxResults: 1,
    type: 'video',
    //videoDuration: 'short',
    key: API_KEY
};


var appId; //replace with 'amzn1.echo-sdk-ams.app.[your-unique-value-here]'; NOTE THIS IS A COMPLETELY OPTIONAL STEP WHICH MAY CAUSE MORE ISSUES THAN IT SOLVES IF YOU DON'T KNOW WHAT YOU ARE DOING


var handlers = {
    
    'LaunchRequest': function () {
        
      this.emit(':ask', "Welcome to youtube. What are you looking for?");  
        
        
    },

    'SearchIntent': function (overrideText) {
        
        var foundTitle;
        
        console.log('Starting Search Intent')
        var alexaUtteranceText = this.event.request.intent.slots.search.value;
        console.log ('Search term is : - '+ alexaUtteranceText)
        var searchFunction = this;

        // Check for required environment variables and throw spoken error if not present
        search(alexaUtteranceText, opts, function(err, results) {
          if(err) {
              return console.log(err)
          }
            else {
          console.dir(results);

                url = results[0].link
                foundTitle = results[0].title;
                uStream(url)
        .pipe(uploadFromStream(s3))


            }

        });
        
        // Create function to upload MP3 file to S3 
        function uploadFromStream(s3) {
            var pass = new Stream.PassThrough();
            var params = {Bucket: S3_BUCKET, Key: 'youtube.mp3', Body: pass};
            s3.upload(params, function(err, data) {
                if (err){
                console.log('S3 upload error: ' + err) 
                    searchFunction.emit(':tell', 'There was an error uploading to S3. Please ensure that the S3 Bucket name is correct in the environment variables and IAM permissions are set correctly');

                } else{
                    console.log ('upload was sucessful')
                    var signedURL;
                    // create a signed URL to the MP3 that expires after 5 seconds - this should be plenty of time to allow alexa to load and cache mp3
                    var signedParams = {Bucket: S3_BUCKET, Key: 'youtube.mp3', Expires: 600, ResponseContentType: 'audio/mpeg'};
                    s3.getSignedUrl('getObject', signedParams, function (err, url) {
                                
                        if (url){
                            searchFunction.response.speak('Playing ' + foundTitle)
                            searchFunction.response.audioPlayer('play', 'REPLACE_ALL', url, '123456789123456789', null, 0);
                            searchFunction.emit(':responseReady');
                        } else {
                            searchFunction.emit(':tell', 'There was an error creating the signed URL. Please ensure that the S3 Bucket name is correct in the environment variables and IAM permissions are set correctly');
                        } 
                        });
                    

              }
            });
            return pass;
        }
        
            
    },
    
    'Unhandled': function() {
        console.log('Unhandled event');
        
        
    },
    
    'AMAZON.StopIntent' : function () {
        console.log('Stop Intent')
        this.response.audioPlayerStop();
        this.response.audioPlayerClearQueue();
        //this.emit(':responseReady');
        
        
        
            
    },
    'AMAZON.CancelIntent' : function () {
        console.log('Cancel Intent')
        this.response.audioPlayerStop();
        this.response.audioPlayerClearQueue();
        this.emit(':responseReady');
        
    },
    
    'AMAZON.ResumeIntent' : function () {
        console.log('Resume Intent')
        this.response.audioPlayerStop();
        this.response.audioPlayerClearQueue();
        this.emit(':responseReady');
        
    },
    
    'AMAZON.PauseIntent' : function () {
        console.log('Pause Intent')
        this.response.audioPlayerStop();
        this.response.audioPlayerClearQueue();
        this.emit(':responseReady');
        
    },
    
    'PlaybackStarted' : function () {
        console.log('Playback started')
        
        
    },
        
    
    'SessionEndedRequest': function () {
        console.log('Session ended request');
        
        console.log(`Session has ended with reason ${this.event.request.reason}`)

        
        
    }
};


exports.handler = function(event, context, callback){
    var alexa = Alexa.handler(event, context);
    alexa.appId = appId;
    alexa.registerHandlers(handlers);
    // Create DynamoDB Table
    //alexa.dynamoDBTableName = 'AlexaAssistantSettings';
    alexa.execute();
};




