'use strict';
const AWS = require('aws-sdk');
var search = require('youtube-search');
var google = require('./node_modules/googleapis');
const ytdl = require('ytdl-core');
var Stream = require('stream');
var url = 'http://youtube.com/watch?v='
var fs = require('fs');
var writemp3 = fs.createWriteStream('/tmp/response.mp3');
var S3_BUCKET = process.env['S3_BUCKET'];
var API_KEY = process.env['API_KEY'];
var s3 = new AWS.S3();
var ffmpeg = require('fluent-ffmpeg');
var command = ffmpeg();
var OAuth2 = google.auth.OAuth2;
var wait = require('wait-one-moment');


var CLIENT_ID = process.env.CLIENT_ID;
var CLIENT_SECRET = process.env.CLIENT_SECRET;
var REDIRECT_URL = process.env.REDIRECT_URL;


console.log('***********Starting new session**************')

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'];

var maxDuration = 30 // max length in seconds
var qualityValue = 140 // This is the youtube ITAG values
// This should download a DASH compatible aac audio stream that is natively playable by Alexa
// For options see here http://en.wikipedia.org/wiki/YouTube#Quality_and_formats

var opts = {
  maxResults: 50,
    type: 'video',
    key: API_KEY
};

var lastPlayedByUser = {};
var ResultsByUser = {};
var CurrentResultByUser = {};
var currentS3URLbyUser = {};

var streamURL;
 
exports.handler = function(event, context) {
    var player = new alextube(event, context);
    player.handle();
};
 
var alextube = function (event, context) {
    this.event = event;
    this.context = context;
};
 
 
alextube.prototype.handle = function () {
    var requestType = this.event.request.type;
    var userId = this.event.context ? this.event.context.System.user.userId : this.event.session.user.userId;
    

 
 
   if (requestType === "LaunchRequest") {
        this.play(streamURL, 0);
 
 
    } else if (requestType === "IntentRequest") {
        var intent = this.event.request.intent;
        
        if (!process.env['S3_BUCKET']){
            this.speak('S3 Bucket Environment Variable not set!')
        } else if (!process.env['API_KEY']){
            this.speak('API KEY Environment Variable not set!')
        }

        if (intent.name === "Play") {
            this.play(streamURL, 0);
 
 
        } else if (intent.name === "SearchIntent") {
            
            var foundTitle;

        
        console.log('Starting Search Intent')
            
                if (!this.event.session.user.accessToken) {
        
    var response = {
        version: "1.0",
        "sessionAttributes": {},
        "response": {
       "outputSpeech": {
         "type": "PlainText",
         "text": "You must link your Google account to use this skill. Please use the link in the Alexa app to authorise your Google Account."
       },
       "card": {
         "type": "LinkAccount"
       },
       "shouldEndSession": true
     }
        
    };
    this.context.succeed(response);
            
        
    }
        ResultsByUser[userId]={};
        CurrentResultByUser={};
        var alexaUtteranceText = this.event.request.intent.slots.search.value;
        console.log ('Search term is : - '+ alexaUtteranceText)
        var searchFunction = this;
        search(alexaUtteranceText, opts, function(err, results) {
          if(err) {
              return console.log(err)
              searchFunction.speak('I could not get any results')
          }
            else {
                ResultsByUser[userId] = results
                console.dir(results[0]);
                var resultNumber=0
                CurrentResultByUser[userId] = 0;
                
                searchFunction.playresult( CurrentResultByUser[userId], userId, 'REPLACE_ALL');
            }

        });
        
        } else if (intent.name === "AMAZON.PauseIntent") {
            console.log('Running pause intent')
            this.stop();
 
 
        } else if (intent.name === "AMAZON.CancelIntent") {
            this.speak('Cancelled');

 
        }else if (intent.name === "AMAZON.NextIntent") {
            this.speak('Cancelled');
            
        } else if (intent.name === "AMAZON.ResumeIntent") {
            console.log('Resume called')
            var lastPlayed = this.loadLastPlayed(userId);
            var offsetInMilliseconds = 0;
            var token = 0;
            var results = ResultsByUser[userId];
            var resultNumber = CurrentResultByUser[userId]
            var url = currentS3URLbyUser[userId];
            console.log('current URL is ' + url)
            if (lastPlayed !== null) {
                console.log(lastPlayed);
                offsetInMilliseconds = lastPlayed.request.offsetInMilliseconds;
                token = this.createToken;
            }
            if (offsetInMilliseconds < 0){
                offsetInMilliseconds = 0
            }
            this.resume(url, offsetInMilliseconds, token);
        }
    } else if (requestType === "AudioPlayer.PlaybackStopped") {
        console.log('Playback stopped')
        this.saveLastPlayed(userId, this.event);
        this.context.succeed(true);
    }else if (requestType === "AudioPlayer.PlaybackPause") {
        console.log('Playback paused')
        this.saveLastPlayed(userId, this.event);
        this.context.succeed(true);
    } else if (requestType === "AudioPlayer.PlaybackStarted") {
        console.log('Playback started')
        
    }
};
 
 alextube.prototype.play = function (audioURL, offsetInMilliseconds, title, tokenValue) {
    var responseText = ' '; 
    if (title){
        responseText = 'Playing ' + title;
    }
    var response = {
        version: "1.0",
        response: {
            shouldEndSession: true,
            "outputSpeech": {
              "type": "PlainText",
              "text": responseText,
            },
            directives: [
                {
                    type: "AudioPlayer.Play",
                    playBehavior: "REPLACE_ALL", 
                    audioItem: {
                        stream: {
                            url: audioURL,
                            token: tokenValue, 
                            expectedPreviousToken: null, 
                            offsetInMilliseconds: offsetInMilliseconds
                        }
                    }
                }
            ]
        }
    };
     console.log('Play Response is')
     console.log(JSON.stringify(response))
    this.context.succeed(response);
}; 

alextube.prototype.resume = function (audioURL, offsetInMilliseconds, tokenValue) {
    
    var resumeResponse = {
        version: "1.0",
        response: {
            shouldEndSession: true,
           
            directives: [
                {
                    type: "AudioPlayer.Play",
                    playBehavior: "REPLACE_ALL", 
                    audioItem: {
                        stream: {
                            url: audioURL,
                            expectedPreviousToken: null, 
                            offsetInMilliseconds: offsetInMilliseconds,
                            token: this.createToken()
                        }
                    }
                }
            ]
        }
    };
    console.log('Resume Response is')
     console.log(JSON.stringify(resumeResponse))
    this.context.succeed(resumeResponse);
};

 alextube.prototype.queue = function (audioURL, offsetInMilliseconds, tokenValue, previousToken) {

    var response = {
        version: "1.0",
        response: {
            shouldEndSession: true,
            directives: [
                {
                    type: "AudioPlayer.Play",
                    playBehavior: "ENQUEUE", 
                    audioItem: {
                        stream: {
                            url: audioURL,
                            token: this.createToken(), 
                            expectedPreviousToken: previousToken, 
                            offsetInMilliseconds: offsetInMilliseconds
                        }
                    }
                }
            ]
        }
    };
    this.context.succeed(response);
};
 
alextube.prototype.stop = function () {
    console.log("Sending stop response")
    var response = {
        version: "1.0",
        response: {
            shouldEndSession: true,
            directives: [
                {
                    type: "AudioPlayer.Stop"
                }
            ]
        }
    };
    this.context.succeed(response);
};

alextube.prototype.playresult = function (resultNumber, userId, playMode) {
    console.log("Processing result")
    var results = ResultsByUser[userId];
    var url = results[resultNumber].id;
    var foundTitle = results[resultNumber].title;
    var playFunction = this;
    var audioStream = ytdl(url,{ filter: 'audioonly', quality: qualityValue });
    

    
    
    var command = ffmpeg()
    .input(audioStream)
    //.noVideo()
    .audioCodec('copy')
    .save('/tmp/output.aac')
    .on('end', function() {
    console.log('Processing finished !');
        
         playFunction.upload(userId);
        
      })
    
    
    

    //audioStream.pipe(uploadFromStream(s3)) 
    
    // Create function to upload stream to S3 
    function uploadFromStream(s3) {
        var pass = new Stream.PassThrough();
        var params = {Bucket: S3_BUCKET, Key: 'youtube' + userId + '.aac', Body: pass};
        s3.upload(params, function(err, data) {
            if (err){
            console.log('S3 upload error: ' + err) 
                playFunction.speak('There was an error uploading to S3');

            } else{
                console.log ('upload was sucessful')
                
                // create a signed URL to the m4a that expires after 10 hours
                var token = playFunction.createToken();
                var signedParams = {Bucket: S3_BUCKET, Key: 'youtube' + userId + '.aac', Expires: 36000, ResponseContentType: 'audio/mpeg'};
                s3.getSignedUrl('getObject', signedParams, function (err, url) {

                    if (url){
                        streamURL = url;
                        //currentS3URLbyUser[userId] = url;
                        currentS3URLbyUser[userId] = 'https://drive.google.com/uc?id=0B8O3IRCgrjaGMTFBR2dnajRKa0E&export=download';
                        if (playMode == 'REPLACE_ALL'){
                            playFunction.play(streamURL, 0, foundTitle, token);
                    }
                    } else {
                        playFunction.speak('There was an error creating the signed URL.');
                    } 
                    });
          }
        });
        return pass;
    }
    
};

alextube.prototype.processresult = function (responseText) {
    var response = {
        version: "1.0",
        "sessionAttributes": {},
        response: {
            "outputSpeech": {
              "type": "PlainText",
              "text": responseText,
            },
            "shouldEndSession": true
        }
        
    };
    this.context.succeed(response);
};
alextube.prototype.speak = function (responseText) {
    console.log('speaking result')
    var response = {
        version: "1.0",
        "sessionAttributes": {},
        response: {
            "outputSpeech": {
              "type": "PlainText",
              "text": responseText,
            },
            "shouldEndSession": true
        }
        
    };
    this.context.succeed(response);
};

alextube.prototype.upload = function (userId) {
    console.log('uploading audio')
    var ACCESS_TOKEN = this.event.session.user.accessToken;
    var oauth2Client = new OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URL);
    oauth2Client.setCredentials({access_token: ACCESS_TOKEN });

    var drive = google.drive({
      version: 'v3',
      auth: oauth2Client
    });
    
    var media = {
        mimeType: 'audio/aac',
        body: fs.createReadStream('/tmp/output.aac')
    };

    var fileMetadata = {
      'name': 'alexayoutubeaudio.aac'
    };
    var uploadFunction = this;
    //var media = fs.createReadStream('/tmp/output.aac')
    listFiles()
    
    function listFiles() {
        var fileID;
        drive.files.list({
        pageSize: 10,
        q: "name='alexayoutubeaudio.aac'",
        fields: "files(id, name)"
        }, function(err, response) {
        if (err) {
          console.log('The API returned an error: ' + err);
          return;
        }
        var files = response.files;
        if (files.length == 0) {
          console.log('No files found.');
            //searchFunction.emit(':tell', "No files found");
            createfile();
        } else {
          console.log('Files:');

            var file = files[0];
            console.log('%s (%s)', file.name, file.id);
            fileID = file.id;
            deletefile(fileID);

        }
        });
    }


    function createfile (){
        console.log('creating new file')
        
        drive.files.create({
           resource: fileMetadata,
           media: media,
           fields: 'id'
        }, function(err, file) {
          if(err) {
            // Handle error
            console.log(err);
          } else {
            console.log('File Id: ', file.id);
             makefilepublic(file.id) 


          }
        });
    }

    function makefilepublic (fileID){
        var body = {
                'value': 'default',
                'type': 'anyone',
                'role': 'reader'
            };
              drive.permissions.create({
                  fileId: fileID,
                resource: body
            }, function(err, res) {
              if(err) {
                // Handle error
                console.log(err);
              } else {
                console.log('Result: ', res);
                  getpubliclink(fileID)

              }
            });
    }
    function getpubliclink (fileID){
              drive.files.get({
                  fileId: fileID,
                  fields: 'webContentLink'
            }, function(err, res) {
              if(err) {
                // Handle error
                console.log(err);
                  uploadFunction.speak('There was an error creating the public URL.');
              } else {
                console.log('Result: ', res);
                  url = res.webContentLink
                  console.log ('webContentLink: ', url)
                  var token = uploadFunction.createToken();
                  if (url){
                        streamURL = url;
                        currentS3URLbyUser[userId] = url;
                      
                      var foundTitle ="Test title"
                      
                      
                          
                          uploadFunction.play(streamURL, 0, foundTitle, token);


                      
                      

                      /*
                        if (playMode == 'REPLACE_ALL'){
                            uploadFunction.play(streamURL, 0, foundTitle, token);
                            
                            
                    }
                    */
                    } else {
                        uploadFunction.speak('There was an error creating the signed URL.');
                    }
                  

              }
            });
    }


    function deletefile (fileID){
        console.log('deleting old file')
        drive.files.delete({
           fileId: fileID
        }, function(err, file) {
          if(err) {
            // Handle error
            console.log(err);
          } else {
            console.log('File deleted');

            createfile();
          }
        });
    }
    

    
};
 
alextube.prototype.saveLastPlayed = function (userId, lastPlayed) {
    lastPlayedByUser[userId] = lastPlayed;
    console.log('Status saved')
    console.log(lastPlayed)
};
 
alextube.prototype.loadLastPlayed = function (userId) {
    var lastPlayed = null;
    
    if (userId in lastPlayedByUser) {
        lastPlayed = lastPlayedByUser[userId];
    }
    return lastPlayed;
};

alextube.prototype.createToken = function() {

  var d = new Date().getTime();

  var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {

    var r = (d + Math.random()*16)%16 | 0;

    d = Math.floor(d/16);

    return (c=='x' ? r : (r&0x3|0x8)).toString(16);

  });

  return uuid;

}